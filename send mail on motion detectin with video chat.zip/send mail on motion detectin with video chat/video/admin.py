from django.contrib import admin
from .models import Chat
# Register your models here.
admin.site.register(Chat)